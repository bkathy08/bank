


<html>
<head><title>Bank Branch</title>
<style>
body{

    background-color:rgb(245, 245, 245);
}
.bank_branch_container{
    width:90%;
    margin:5% auto;
    //background-color: brown;
}
.bank_branch_container img{
    
    margin:4% auto;
    padding:2%;
    box-shadow: 1px 1px 5px black;

}


</style>


</head>
<body>
<?php include 'header.php'; ?> 
<div class="bank_branch_container">
<div class="bank_branch_container_inner">
<img src="img\Branch\West_Bengal1.jpg">
<img src="img\Branch\Delhi1.jpg">
<img src="img\Branch\Gujrat1.jpg">
<img src="img\Branch\Derjeeling1.jpg">
<img src="img\Branch\Madhyapradesh1.jpg">
<img src="img\Branch\Jharkhand1.jpg">
</div>
</div>
<?php include 'footer.php'; ?> 
</body>
<html>