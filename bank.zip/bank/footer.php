<link rel="stylesheet" type="text/css" href="css/footer.css">
<footer>
<div class="container">
<div class="follow_us">
    <label>Follow Us</label>
    <ul>
        <li><a href="https://www.facebook.com/gcashofficial">Facebook</a></li>
        <li><a href="https://x.com/gcashofficial">Twitter</a></li>
        <li><a href="https://www.instagram.com/gcashofficial">Instagram</a></li>
    
    </ul>
    </div>
    <div class="contact" id="contactus">
        <label>Contact Us</label>
        <ul>
            <p>West Global Center, 9th Avenue cor. 30th Street </p><p>Bonifacio Global City, Taguig.</p>
            <p>Tel :  (02) 7213-9999</p>
            
        </ul>
    </div>
        <div class="links">
            <ul>    
            <li><a href="index.php#aboutus" target="_blank">About Us</a></li>
            </ul><br>
    </div>

  
    
    </div>
    <div class="copyright">
        <span>Copyright &copy; 2024 CashG. All rights reserved.</span>
    </div>

</footer>