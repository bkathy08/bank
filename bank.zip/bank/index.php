<html>
<title>CashG</title>
<head>
   <link rel="stylesheet" type="text/css" href="css/index.css">
   <link rel="shortcut icon" href="img/chase.jpg">
    </head>
 
<body>
<?php include'header.php'?>
<div class="index_container">
    </div>
    <video id="video1" class="background-video video1" autoplay muted playsinline preload="auto"></video>
    <video id="video2" class="background-video video2" autoplay muted playsinline preload="auto"></video>

        <script>
        const videoSources = [
            "video/ADDS.mp4",
            
        ];
        
        const videoElement1 = document.getElementById('video1');
        const videoElement2 = document.getElementById('video2');
        let currentVideoIndex = 0;
        let isVideo1Playing = true;

        function playNextVideo() {
            // Alternate between video elements
            const currentVideo = isVideo1Playing ? videoElement1 : videoElement2;
            const nextVideo = isVideo1Playing ? videoElement2 : videoElement1;

            // Set the next video source and prepare it
            currentVideoIndex = (currentVideoIndex + 1) % videoSources.length;
            nextVideo.src = videoSources[currentVideoIndex];
            nextVideo.load();
            
            // Start playing the next video
            nextVideo.play();

            // Crossfade effect: fade out the current video and fade in the next
            currentVideo.style.opacity = 0;
            nextVideo.style.opacity = 1;

            // Switch the playing flag
            isVideo1Playing = !isVideo1Playing;
        }

        // Start the slideshow by loading the initial video
        videoElement1.src = videoSources[currentVideoIndex];
       
        // Ensure the first video plays
        videoElement1.play();
    </script>

    <div class="online_services">
        <h4>Online Services</h4>
        <ul>
            <a href="customer_reg_form.php"><li>Open Account</li></a>
            <a href="#" id="ebanking" ><li><div class="ebanking">Internet Banking
                <div class = "ebanking_options">
                <ul>
                    <a href="customer_login.php"><li>Login </li></a>
                    <a href="ebanking_reg_form.php"><li>Register</li></a>
                </ul>
            </div>
        </div>
   
        </ul>
   
</div>

       
    
<?php include 'footer.php';?>
</body>

</html>