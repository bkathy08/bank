<link rel="stylesheet" type="text/css" href="css/header.css">
        <div class="header_main">
		<div class="navBar">
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="staff_login.php"> Login</a></li>
				<li><a href="index.php"> Logout</a></li>
			
			</ul>
		</div>
	 <a href="index.php"><div class="logo-name">
			<div class="logo">
             <img class="logo_img" src="img/chase.jpg">
			</div>
			
			<div class="name">
				<h5> CashG</h5></a><br>
				
			</div>
        </div>
            
            
            <div class="dif_banking">

			
		</div>
            
           
			
	</div>